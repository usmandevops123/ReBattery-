import SwiftUI

struct DashboardView: View {

    var body: some View {

        VStack {

            Text("ReBattery")

                .font(.custom("Phosphate", size: 36))

                .foregroundColor(.white)

                .padding()

                .background(Color(hex: "#61BFAD"))

            Spacer()

            Text("My Points")

                .font(.custom("Phosphate", size: 24))

                .padding()

            Text("10")

                .font(.custom("Phosphate", size: 48))

                .bold()

            Text("Items Recycled")

                .font(.custom("Phosphate", size: 24))

                .padding()

            Text("34")

                .font(.custom("Phosphate", size: 48))

                .bold()

            Spacer()

            Button(action: {

                // Action for recycling batteries

            }) {

                Text("Earn Points by Recycling Batteries")

                    .padding()

                    .background(Color.green)

                    .foregroundColor(.white)

                    .cornerRadius(10)

            }

            .padding()

            Button(action: {

                // Action for getting started

            }) {

                Text("Get started")

                    .padding()

                    .foregroundColor(.blue)

            }

            Spacer()

        }

    }

}
 
