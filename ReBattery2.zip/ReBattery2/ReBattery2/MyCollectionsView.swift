import SwiftUI

struct MyCollectionsView: View {
    @Binding var points: Int  // Use Binding to allow updates from ContentView

    @State private var phoneAchieved: Int = 0
    @State private var forkKnifeAchieved: Int = 0
    @State private var laptopAchieved: Int = 0
    
    let items = [
        ("Laptop", "laptopcomputer", 10),
        ("Fork/Knife", "fork.knife", 7),
        ("Phone", "iphone", 5)
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("MY COLLECTIONS")
                .font(.custom("Phosphate", size: 24))
                .foregroundColor(Color(hexCode: "#61BFAD"))
            
            // Display points section with a highlight color
            Text("Your points are currently: \(points)")
                .font(.custom("Phosphate", size: 16))
                .foregroundColor(Color(hexCode: "#61BFAD"))
            
            // Separate Milestones Achieved Section
            VStack(spacing: 20) {
                Text("Milestones Achieved")
                    .font(.custom("Phosphate", size: 20))
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Phone Milestone Progress Bar
                HStack {
                    Image(systemName: "iphone")
                        .resizable()
                        .frame(width: 20, height: 20)  // Reduced icon size
                        .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                    ProgressBar(progress: $phoneAchieved, maxValue: 5)
                        .frame(width: 200, height: 30)
                    Text("\(phoneAchieved)/5")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.black)
                }
                
                // Fork/Knife Milestone Progress Bar
                HStack {
                    Image(systemName: "fork.knife")
                        .resizable()
                        .frame(width: 20, height: 20)  // Reduced icon size
                        .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                    ProgressBar(progress: $forkKnifeAchieved, maxValue: 7)
                        .frame(width: 200, height: 30)
                    Text("\(forkKnifeAchieved)/7")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.black)
                }
                
                // Laptop Milestone Progress Bar
                HStack {
                    Image(systemName: "laptopcomputer")
                        .resizable()
                        .frame(width: 20, height: 20)  // Reduced icon size
                        .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                    ProgressBar(progress: $laptopAchieved, maxValue: 10)
                        .frame(width: 200, height: 30)
                    Text("\(laptopAchieved)/10")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.black)
                }
            }
            .padding(.top)
            
            // Separate My Collections Section
            Text("My Collections Gallery")
                .font(.custom("Phosphate", size: 20))
                .foregroundColor(Color(hexCode: "#61BFAD"))
            
            // Grid layout for achievements with icons
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 20) {
                ForEach(items, id: \.0) { item in
                    VStack {
                        Image(systemName: item.1)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        Text(item.0)
                            .font(.custom("Phosphate", size: 16))
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
                }
            }
            .padding(.top)
        }
        .padding()
        .onAppear {
            // Set all counters to 0 for now
            phoneAchieved = 0
            forkKnifeAchieved = 0
            laptopAchieved = 0
        }
    }
}

struct ProgressBar: View {
    @Binding var progress: Int
    var maxValue: Int
    
    var body: some View {
        ZStack {
            // Background of the progress bar (battery shape)
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.gray.opacity(0.2))
            
            // Foreground of the progress bar (filled part)
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(hexCode: "#61BFAD"))
                .frame(width: CGFloat(progress) / CGFloat(maxValue) * 200, height: 30)
                .animation(.easeInOut(duration: 0.5), value: progress)  // Apply animation when progress updates
        }
    }
}

