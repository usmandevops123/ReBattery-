import SwiftUI

struct UploadView: View {
    var body: some View {
        VStack(spacing: 40) {
            Text("UPLOAD THE PICTURE")
                .font(.custom("Phosphate", size: 24))
                .foregroundColor(Color(hex: "#61BFAD"))
            Image(systemName: "viewfinder")
                .font(.system(size: 120))
                .foregroundColor(Color(hex: "#61BFAD"))
            Button(action: {
                // Action for "Upload Image"
            }) {
                Text("Upload Image")
                    .font(.custom("Phosphate", size: 16))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color(hex: "#61BFAD"))
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}

