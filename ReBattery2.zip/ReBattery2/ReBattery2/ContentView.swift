import SwiftUI

struct ContentView: View {
    @State private var points: Int = 10  // Example points value

    var body: some View {
        NavigationView {
            TabView {
                HomeView(points: $points)  // Pass points as a binding to HomeView
                    .tabItem {
                        Image(systemName: "square")
                        Text("Dashboard")
                    }
                GoalsView()
                    .tabItem {
                        Image(systemName: "map")
                        Text("Map")
                    }
                UploadView()
                    .tabItem {
                        Image(systemName: "camera")
                        Text("Upload")
                    }
                MyCollectionsView(points: $points)  // Pass points as a binding to MyCollectionsView
                    .tabItem {
                        Image(systemName: "info.circle")
                        Text("My Collections")
                    }
            }
            .accentColor(Color(hexCode: "#61BFAD"))
            .navigationBarTitleDisplayMode(.inline)  // Inline title
            .navigationTitle("ReBattery")  // Set the header for the content screen
            .onAppear {
                // Customize the navigation bar color theme here
                let appearance = UINavigationBarAppearance()
                appearance.configureWithOpaqueBackground()
                appearance.backgroundColor = UIColor(Color(hexCode: "#61BFAD"))  // Set the background color
                appearance.titleTextAttributes = [.foregroundColor: UIColor.white]  // Title color
                appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]  // Large title color
                UINavigationBar.appearance().standardAppearance = appearance
                UINavigationBar.appearance().compactAppearance = appearance
                UINavigationBar.appearance().scrollEdgeAppearance = appearance
            }
        }
    }
}

