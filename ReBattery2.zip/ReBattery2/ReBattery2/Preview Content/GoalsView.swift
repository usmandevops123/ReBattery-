import SwiftUI
import MapKit
import CoreLocation
 
// MARK: - Location Struct
struct Location: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
    
    static func ==(lhs: Location, rhs: Location) -> Bool {
        return lhs.id == rhs.id && lhs.coordinate.latitude == rhs.coordinate.latitude && lhs.coordinate.longitude == rhs.coordinate.longitude
    }
}
 
// MARK: - Location Manager
class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var userLocation: CLLocation? = nil
    private let locationManager = CLLocationManager()
 
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
    }
 
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            DispatchQueue.main.async {
                self.userLocation = location
            }
        }
    }
 
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to get user location: \(error.localizedDescription)")
    }
}
 
// MARK: - GoalsView
struct GoalsView: View {
    @StateObject private var locationManager = LocationManager()
    @State private var batteryDropOffPoints: [Location] = []
 
    // Define Villa Doria d'Angri location as a starting point
    private let villaDoriaLocation = Location(
        name: "Villa Doria d'Angri",
        coordinate: CLLocationCoordinate2D(latitude: 40.822975, longitude: 14.216369)
    )
 
    var body: some View {
        VStack {
            Text("Battery Drop-off Points")
                .font(.custom("Phosphate", size: 32))
                .foregroundColor(Color(hexCode: "#61BFAD"))
                .padding(.top)
            
            CustomMapView(
                userLocation: locationManager.userLocation ?? CLLocation(latitude: villaDoriaLocation.coordinate.latitude, longitude: villaDoriaLocation.coordinate.longitude),
                villaLocation: villaDoriaLocation,
                batteryDropOffPoints: batteryDropOffPoints
            )
            .frame(height: 400)
            .onAppear {
                searchNearbyBatteryDropOffs()
            }
        }
    }
 
    private func searchNearbyBatteryDropOffs() {
        let queries = ["Tabacchi", "Farmacia"]
 
        for query in queries {
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = query
            request.region = MKCoordinateRegion(
                center: villaDoriaLocation.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
            )
 
            let search = MKLocalSearch(request: request)
            search.start { response, error in
                if let error = error {
                    print("Error searching for \(query): \(error.localizedDescription)")
                    return
                }
                
                guard let response = response else { return }
                let locations = response.mapItems.prefix(5).map { item in
                    Location(name: "\(query): \(item.name ?? "Unknown")", coordinate: item.placemark.coordinate)
                }
                
                DispatchQueue.main.async {
                    self.batteryDropOffPoints.append(contentsOf: locations)
                }
            }
        }
    }
}
 
// MARK: - CustomMapView
struct CustomMapView: UIViewRepresentable {
    var userLocation: CLLocation?
    var villaLocation: Location
    var batteryDropOffPoints: [Location]
 
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.showsUserLocation = true
        mapView.userTrackingMode = .follow
        mapView.delegate = context.coordinator
        return mapView
    }
 
    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Center the map on Villa Doria d'Angri
        let initialRegion = MKCoordinateRegion(
            center: villaLocation.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        mapView.setRegion(initialRegion, animated: true)
 
        // Remove previous annotations
        mapView.removeAnnotations(mapView.annotations)
        
        // Add Villa Doria d'Angri annotation with a custom symbol
        let villaAnnotation = MKPointAnnotation()
        villaAnnotation.coordinate = villaLocation.coordinate
        villaAnnotation.title = villaLocation.name
        mapView.addAnnotation(villaAnnotation)
        
        // Add annotations for nearby battery drop-off points
        for location in batteryDropOffPoints {
            let annotation = MKPointAnnotation()
            annotation.coordinate = location.coordinate
            annotation.title = location.name
            mapView.addAnnotation(annotation)
        }
    }
 
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
 
    class Coordinator: NSObject, MKMapViewDelegate {
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            // Customize Villa Doria d'Angri's annotation view
            if annotation.title == "Villa Doria d'Angri" {
                let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "villaLocation")
                annotationView.markerTintColor = .red // Different color for current location
                annotationView.glyphText = "🏛" // Icon for Villa Doria d'Angri
                annotationView.canShowCallout = true
                return annotationView
            }
 
            // Default annotation view for other drop-off points
            let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "batteryDropOff")
            annotationView.markerTintColor = .green
            annotationView.canShowCallout = true
            annotationView.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            return annotationView
        }
        
        func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
            guard let annotation = view.annotation else { return }
            
            let locationCoordinate = annotation.coordinate
            let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: locationCoordinate))
            mapItem.name = annotation.title ?? "Destination"
 
            // Show action sheet to select Apple Maps or Google Maps
            let alert = UIAlertController(title: "Open in Maps", message: "Select your preferred map", preferredStyle: .actionSheet)
            
            alert.addAction(UIAlertAction(title: "Apple Maps", style: .default, handler: { _ in
                // Open in Apple Maps
                mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeWalking])
            }))
            
            alert.addAction(UIAlertAction(title: "Google Maps", style: .default, handler: { _ in
                // Open in Google Maps
                if let url = URL(string: "comgooglemaps://?daddr=\(locationCoordinate.latitude),\(locationCoordinate.longitude)&directionsmode=walking"),
                   UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                } else {
                    // Fallback to Google Maps website if the app isn't installed
                    if let url = URL(string: "https://www.google.com/maps/dir/?api=1&destination=\(locationCoordinate.latitude),\(locationCoordinate.longitude)&travelmode=walking") {
                        UIApplication.shared.open(url)
                    }
                }
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            // Present the alert
            UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
}
