//
//  ReBattery2Tests.swift
//  ReBattery2Tests
//
//  Created by Muhammad Usman on 05/11/2024.
//

import Testing
@testable import ReBattery2

struct ReBattery2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
